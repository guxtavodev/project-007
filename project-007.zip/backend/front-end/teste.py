# Run this app with `python app.py` and
# visit http://127.0.0.1:8050/ in your web browser.

from dash import Dash, html, dcc
import plotly.express as px
import pandas as pd

app = Dash(__name__)

# assume you have a "long-form" data frame
# see https://plotly.com/python/px-arguments/ for more options
df = pd.DataFrame({
    "Serviços": ["Instalação", "Conserto", "Clima", "Instalação", "Conserto", "Clima"],
    "Amount": [499, 233, 2, 10, 400, 5],
    "City": ["Santo Amaro", "Santo Amaro", "Santo Amaro", "Saubara", "Saubara", "Saubara"]
})

fig = px.bar(df, x="Serviços", y="City", color="Serviços", barmode="group")

app.layout = html.Div(children=[
    html.H1(children='Hello Dash'),

    html.Div(children='''
        Dash: A web application framework for your data.
    '''),

    dcc.Graph(
        id='example-graph',
        figure=fig
    )
])

if __name__ == '__main__':
    app.run_server(debug=True)