from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
#from api.index import API
import sqlite3 as sql

# Criando a aplicação
app = Flask(__name__, template_folder="front-end")

def executarDB(cmd):
	db = sql.connect()
	cursor = db.cursor()
	cursor.execute(cmd)
	res = cursor.fetchall()
	db.commit()
	db.close()
	return res


# Deixando a API Utilizavel
CORS(app)

#apiV = API(app)

@app.route("/")
def home():
	return render_template("index.html")

@app.route("/cadastro")
def cadastrar():
	return render_template("cadastro.html")

@app.route("/entrar")
def acess():
	return render_template("login.html")

@app.route("/newsletter")
def acessNewsletter():
	return render_template("newsletter.html")

@app.route("/api/send/<plano>")
def envioDeNewsletter(plano):
	info = request.get_json()
	author = info["author"]
	db = sql.connect("banco.db")
	cursor = db.cursor()
	userlest = cursor.execute('SELECT newsletter FROM users WHERE username = ?', (author,))
	nameNewsletter = userlest.fetchone()
	newsinfo = cursor.execute("SELECT description, url, clientes FROM newsletter WHERE nome = ?", (nameNewsletter,))
	infosNewsletter = newsinfo.fetchall()
	db.close()

	if plano == "GRÁTIS":
		pass 
		# Envio normal ou HTML
	if plano == "PREMIUM":
		pass 
		# Envio com Markdown e Curtidas
	if plano == "SOCIETY":
		pass 


# API's
@app.route("/api/cadastro", methods=["POST"])
def cadastro():
		data = request.get_json()
		username = data["username"]
		senha = data["password"]
		email = data["email"]
		tel = data["tel"]

		if username == "" or senha == "" or email == "" or tel == "":
			return jsonify({"resp": "Imcomplete"})
		else:
			pass


		existe = False
	
		

		try:
			bd = sql.connect("banco.db")
			cursor = bd.cursor()
			r = cursor.execute("""
				SELECT * FROM users WHERE username = ?
			""", (username,))

			dado = r.fetchone()
			#print(r.fetchone())
			print("HM")
				
			bd.close()
			if dado == None:
				pass
			else:
				return jsonify({"resp": "Já existe"})
				

			bancoDeDados = sql.connect("banco.db")
			cursor = bancoDeDados.cursor()
			cursor.execute("""
				INSERT INTO users (username, senha, email, tel) VALUES (?,?,?,?)
			""", (username, senha, email, tel))
			cursor.execute("""
				INSERT INTO newsletter (nome, description, author, url) VALUES (?,?,?,?)
			""", (f"Newsletter do(a) {username}", "", username, ""))
			bancoDeDados.commit()
			bancoDeDados.close()

			print("NOVO USUÁRIO CADASTRADO")
			return jsonify({"resp": "OK"})
		except Exception as e:
			print(e)

@app.route("/api/login", methods=["GET"])
def entrar():
		# data = request.get_json()
		username = request.args.get("username")
		senha = request.args.get('password')

		# Verificar se o usuário existe
		
		db = sql.connect("banco.db")
		cursor = db.cursor()
		s = cursor.execute("""
			SELECT * FROM users WHERE username = ?
		""", (username,))
		dado = s.fetchone()
		cursor.close()
		if dado == None:
			return jsonify({"resp": "Find Not User"})
		else:
			pass
		

		# Verificar se a senha é correta

		db = sql.connect("banco.db")
		cursor = db.cursor()
		cursor.execute("SELECT senha FROM users WHERE username = ?", (username,))
		senhaCorreta = cursor.fetchall()[0][0]
		db.close()

		if senha == senhaCorreta:
			return jsonify({
				"resp":"Senha correta"
			})
		else:
			return jsonify({
				"resp": "Senha incorreta"
			})

@app.route("/api/edit/newsletter", methods=["POST"])
def editarNewsletter():
		data = request.get_json()
		nome = data["name"]
		desc = data["description"]
		autor = data["author"]
		URL_curtidas = data["url"]

		db = sql.connect("banco.db")
		cursor = db.cursor()
		cursor.execute("""
			INSERT INTO newsletters (nome, description, author, url) VALUES (?,?,?,?)
		""", (nome, desc, autor, URL_curtidas))
		db.commit()
		db.close()
		return jsonify({"resp": "CONCLUÍDO"})

@app.route("/api/newsletter/<infos>/add")
def addCliente(infos):
	infod = infos.split("_")
	nome = infod[0]
	desc = infod[1]





if __name__ == "__main__":
	app.run(host="0.0.0.0")

