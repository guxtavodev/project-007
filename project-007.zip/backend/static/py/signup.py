from browser import document, console, alert, html, window, bind
from browser.template import Template
from browser.local_storage import storage

@bind("#cadast", "click")
def printar(ev):
	console.log("Oii")
