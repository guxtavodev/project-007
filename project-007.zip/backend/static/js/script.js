var button = document.getElementById("cadast")

$("#cadast").click(function() {
	var username = document.getElementById("name")
	var senha = document.getElementById("password")
	var email = document.getElementById("emailz")

	console.log(`
		DADOS NOVOS:
		Nome: ${username.value}
		Senha: ${senha.value}
		Email: ${email.value}
	`)

	var resp = axios.post("http://127.0.0.1:5000/api/cadastro", {
		"username": username.value,
		"password": senha.value,
		"email": email.value,
		"tel": "0000"
	}).then((resp) => {
		console.log(resp.data["resp"])
		r = resp.data["resp"]
		if(r === "OK") {
			alert("Você teve seu cadastro concluído com sucesso!")
			localStorage.setItem("username", username.value)
			window.location.href = "http://127.0.0.1:5000/"
		} 
		if(r === "Já existe") {
			alert("Já existe um usuário com esse nome!")
		}
	})
})

$("#lg").click(function() {
	var username = document.getElementById("name")
	var senha = document.getElementById("password")

	var resp = axios.get(`http://127.0.0.1:5000/api/login?username=${username.value}&password=${senha.value}`).then((resp) => {
		json = resp.data

		console.log(json["resp"])
		if(json["resp"] === "Find Not User") {
			alert("Usuário não existe")
		}
		if(json["resp"] === "Senha incorreta") {
			alert("Sua senha está incorreta!")
		}
		if(json['resp'] === "Senha correta") {
			alert("Prontinho, Log-in feito com sucesso!")
			localStorage.setItem("username", username.value)
			window.location.href = "http://127.0.0.1:5000/"
		}
	})
})

